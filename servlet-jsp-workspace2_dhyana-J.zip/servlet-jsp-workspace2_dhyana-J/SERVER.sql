--사용자의 요청에 따른 실행할 SQL문 기술

-- *회원서비스
-- 1. 로그인요청시 실행할 sql문 (만약에 일치하는 회원 조회된다면 오로지 "한 행"만 조회될것!)
-- Prepared Statement쓸 것이므로 ? 써주자.
SELECT * FROM MEMBER
WHERE USER_ID = ?
    AND USER_PWD= ?
    AND STATUS = 'Y';

-- 2. 사용자가 회원가입 요청시 실행할 sql문
INSERT INTO MEMBER(USER_NO, USER_ID, USER_PWD, USER_NAME, PHONE, EMAIL, ADDRESS, INTEREST) 
VALUES(SEQ_UNO.NEXTVAL,?,?,?,?,?,?,?);


-- 3. 정보변경 요청 시 실행할 sql문
UPDATE
        MEMBER
    SET USER_NAME=?
      , PHONE=?
      , EMAIL=?
      , ADDRESS=?
      , INTEREST=?
      , MODIFY_DATE=SYSDATE
    WHERE
        USER_ID=?;
        
-- 4. 갱신된 회원 정보 조회요청 시 실행할 sql문
SELECT
        USER_NO
     ,  USER_ID
     ,  USER_PWD
     ,  USER_NAME
     ,  PHONE
     ,  EMAIL
     ,  ADDRESS
     ,  INTEREST
     ,  ENROLL_DATE
     ,  MODIFY_DATE
     ,  STATUS
 FROM MEMBER
 WHERE USER_ID=?
   AND STATUS='Y';

-- 5. 비밀번호 변경 요청 시 실행할 SQL문
UPDATE MEMBER
    SET USER_PWD=?
    WHERE USER_ID=?
    AND USER_PWD=?;

-- 6. 회원탈퇴 요청 시 실행할 sql문
UPDATE
        MEMBER
    SET STATUS='N'
    WHERE USER_ID=?
    AND USER_PWD=?;
    
    select * from member;
    
-- *공지사항 서비스
-- 1. 공지사항 리스트조회할 때 실행할 sql문
SELECT
       NOTICE_NO
     , NOTICE_TITLE
     , USER_ID
     , COUNT
     , CREATE_DATE
 FROM NOTICE N
 JOIN MEMBER ON(NOTICE_WRITER=USER_NO)
 WHERE N.STATUS='Y'
 ORDER
    BY NOTICE_NO DESC;

INSERT INTO NOTICE VALUES(SEQ_NNO.NEXTVAL,'세번째 공지사항입니다.','세번째 공지사항 내용입니다.','1',0,SYSDATE,'Y');

SELECT * FROM NOTICE;

COMMIT;

-- 2. 공지사항 등록요청시 실행할 sql문
INSERT
    INTO NOTICE
    (
        NOTICE_NO
    ,   NOTICE_TITLE
    ,   NOTICE_CONTENT
    ,   NOTICE_WRITER
    )
    VALUES
    (
        SEQ_NNO.NEXTVAL
        ,?
        ,?
        ,?
        );
        
--3. 공지사항 상세조회요청시 실행할 sql문
-- 3_1. 해당 공지사항만 조회수 1 증가
UPDATE
        NOTICE
        SET COUNT = COUNT+1
        WHERE NOTICE_NO = ?
            AND STATUS='Y';
            
-- 3_2. 해당 공지사항만 조회하는 SQL
SELECT
      NOTICE_NO
    , NOTICE_TITLE
    , NOTICE_CONTENT
    , USER_ID
    , CREATE_DATE
    FROM NOTICE N
    JOIN MEMBER ON(NOTICE_WRITER=USER_NO)
    WHERE NOTICE_NO=?
      AND N.STATUS='Y';
      
-- 4. 공지사항 수정하기 요청 시 실행할 sql문
UPDATE
        NOTICE
    SET NOTICE_TITLE = ?
     ,  NOTICE_CONTENT = ?
    WHERE NOTICE_NO = ?;
        
-- 5. 공지사항 삭제하기 요청 시 실행할 sql문
UPDATE
        NOTICE
    SET STATUS = 'N'
    WHERE NOTICE_NO = ?;
    
SELECT * FROM NOTICE;

DELETE FROM NOTICE WHERE NOTICE_NO BETWEEN 4 AND 14;

COMMIT;