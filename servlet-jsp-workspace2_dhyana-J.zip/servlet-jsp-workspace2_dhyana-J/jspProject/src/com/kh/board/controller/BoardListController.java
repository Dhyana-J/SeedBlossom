package com.kh.board.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.board.model.service.BoardService;
import com.kh.board.model.vo.Board;
import com.kh.board.model.vo.PageInfo;

/**
 * Servlet implementation class BoardListController
 */
@WebServlet("/list.bo")
public class BoardListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardListController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// ------------------ 페이징 처리 --------------------
		int listCount; // 현재 게시글의 개수
		int currentPage; // 사용자가 요청한 페이지(즉, 현재페이지)
		int pageLimit; // 한 페이지 하단에 보며질 페이지 최대 개수
		int boardLimit; // 한 페이지당 표시될 게시글 최대 개수
		
		int maxPage; // 전체 페이지 중 마지막 페이지 숫자
		int startPage; // 현재 사용자가 요청한페이지 하단에 보여질 페이징 바의 시작 수 
		int endPage; // 현재 사용자가 요청한페이지 하단에 보여질 페이징 바의 끝 수
		
		
		
		// *listCount : 현재 일반 게시판 총 게시글 개수
		listCount = new BoardService().selectListCount();
		
		// *currentPage : 사용자가 요청한 페이지 (즉, 현재페이지)
		currentPage=Integer.parseInt(request.getParameter("currentPage"));
		
		// * pageLimit : 한 페이지 하단에 보여질 페이지 최대갯수 (몇 개 단위씩 보여지게 할건지)
		pageLimit = 10;
		
		// * boardLimit : 한 페이지 내에 보여질 게시글 최대갯수 (몇 개 단위씩 보여지게 할건지)
		boardLimit = 10;
		
		// * maxPage : 제일 마지막 페이지 수 
		/*
		 * listCount, boardLimit에 영향을 받음
		 * 
		 * ex) boardLimit : 10이라는 가정하에
		 * 
		 * 총갯수	boardLimit			maxPage
		 * 100 / 10 		=>		  10
		 * 101.0 / 10		=> 10.1 => 11
		 * 102.0 / 10		=> 10.2 => 11
		 * ....
		 * 109.0 / 10		=> 10.9	=> 11
		 * 무조건 올림처리해주면 maxPage 뽑아낼 수 있다.
		 * 
		 * 총게시글수(실수)/boardLimit => 올림처리 => maxPage
		 */
		
		//몫이랑 나머지 활용해서도 maxPage 구할 수 있지 않을까? 방법은 매우 다양한가보다.
		
		maxPage = (int)Math.ceil((double)listCount/boardLimit);
		
		// * startPage : 페이징 바의 시작 수
		/*
		 * currentPage, pageLimit 에 영향을 받음
		 * 
		 * ex) pageLimit : 10이라는 가정 하에
		 * 		startPage : 1, 11, 21, 31,... => n*10 + 1 ===> n * pageLimit + 1 
		 * 
		 * 	currentPage = 1  => 1  => 0 * 10 + 1
		 *  currentPage = 5  => 1  => 0 * 10 + 1 
		 *  currentPage = 10 => 1  => 0 * 10 + 1 
		 *  							n=0
		 *  
		 *  currentPage = 20 => 11 => 1 * 10 + 1
		 *  							n=1
		 *  
		 *  currentPage = 1 ~ 10 => n=0
		 *  currentPage = 11 ~ 20 => n-1  
		 *  
		 *  n은? pageLimit으로 나눈 나머지가 1 이상일 때의 몫
		 *  
		 *  n = (currentPage-1)/pageLimit
		 */
		
		startPage = (currentPage-1)/pageLimit*pageLimit + 1; //일반수학이랑 헷갈리면 안됨. 여기서 / 연산은 몫만 뱉어냄!
		
		// * endPage : 현재 사용자가 요청한페이지 하단에 보여질 페이징 바의 끝 수
		/*
		 * startPage, pageLimit에 기본적으로 영향받음
		 * ex)pageLimit : 10이라는 가정하에
		 * 
		 * startPage : 1 => endPage : 10
		 * startPage : 11 => endPage : 20
		 * startPage : 21 => endPage : 30
		 * 
		 */
		endPage = startPage + pageLimit - 1;
		
		// 만약 maxPage가 고작 13까지밖에 안된다면? endPage를 다시 13으로 해줘야된다.
		if(endPage > maxPage) {
			endPage = maxPage;
		}
		
		PageInfo pi = new PageInfo(listCount, currentPage, pageLimit, boardLimit, maxPage, startPage, endPage);
		
		ArrayList<Board> list = new BoardService().selectList(pi);
		
		request.setAttribute("pi",pi);
		request.setAttribute("list",list);
		
		request.getRequestDispatcher("views/board/boardListView.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
