package com.kh.board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.kh.board.model.service.BoardService;
import com.kh.board.model.vo.Attachment;
import com.kh.board.model.vo.Board;
import com.kh.common.MyFileRenamePolicy;
import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class BoardInsertController
 */
@WebServlet("/insert.bo")
public class BoardInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardInsertController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");
			
//			System.out.println(request.getParameter("category")); null값 넘어옴
			// 일반방식 아닌 multipart/form-data 로 전송할 경우 request로 값 못뽑는다.
			// HttpServletRequest => MultipartRequest 변환한 후 그 후에 뽑을 수 있음
			
			// 우선 enctype이 multipart/form-data로 잘 전송되었을 경우 전반적인 내용들이 수행되게끔
			if(ServletFileUpload.isMultipartContent(request)) {
				
				// >> 요청시 전달된 파일 업로드 (서버에 세팅해놓은 폴더에 저장) 처리
				// 1. 전달되는 파일을 처리할 작업내용(전달되는 파일의 용량제한, 전달되는 파일을 저장할 폴더 경로)
				// 전송파일 용량 제한 (int maxSize => byte단위)
				int maxSize = 10 * 1024 * 1024;
				
				// 1_2. 전달되는 파일을 저장할 서버의 폴더 물리적인 경로 알아내기 (String savePath)
				String savePath = request.getSession().getServletContext().getRealPath("/resources/board_upfiles/");
				
				// 2. 전달되는 파일명 수정작업 및 서버에 업로드 작업
				/*
				 * 파일업로드를 위한 외부 라이브러리 : cos.jar (com.oreilly.servlet의 약자)
				 * 다운로드 링크 : http://www.servlets/com/cos
				 *  > HttpServletRequest request => MultipartRequest multiRequest 반환 (해당 객체 생성)
				 *  
				 *  첨부한 파일을 업로드할 때 원본명그대로 업로드하지 않는게 일반적이다.
				 *  - 중복된 이름의 파일이 있을 수도 있고, 한글/특수문자/띄어쓰기가 포함된 파일일 수도 있기 때문이다!
				 *  
				 *  => 기본적인 수정명 작업을 해주는 객체 => cos에서 제공하는 DefaultFileRenamePolicy객체
				 *  => 내부적으로 rename() 메소드가 실행되면서 파일명 수정진행됨
				 *  => 기존에 동일한 파일명이 있을 경우 뒤에 카운팅된 숫자를 붙여줌
				 *  	ex) aaa.jpg , aaa1.jpg, aaa2.jpg, ...
				 *  
				 *  단, 내입맛대로 수정명작업 가능!!
				 *  
				 */
				
//				MultipartRequest multiRequest = new MultipartRequest(request, savePath, maxSize, "UTF-8", new DefaultFileRenamePolicy());
				MultipartRequest multiRequest = new MultipartRequest(request, savePath, maxSize, "UTF-8", new MyFileRenamePolicy());
				
				
				// >> 요청시 전달된 값들을 뽑아서 DB에 INSERT하는 서비스 요청
				// 1. Board 테이블에 Insert할 카테고리번호, 제목, 내용, 작성자회원번호 뽑아서 Board객체에 담기
				String category = multiRequest.getParameter("category"); // "10"
				String boardTitle = multiRequest.getParameter("title");
				String boardContent = multiRequest.getParameter("content");
				String boardWriter = multiRequest.getParameter("userNo");
				
				Board b = new Board();
				
				b.setCategoryNo(category);
				b.setBoardTitle(boardTitle);
				b.setBoardContent(boardContent);
				b.setBoardWriter(boardWriter);
				
				
				// 2. Attachment 테이블에 Insert한 원본명, 수정명(실제서버에 업로드된명), 저장된 폴더경로를 Attachment객체에 담기
				// (만일, 첨부파일이 없었다면 Attachment 객체 null로 초기화)
				
				Attachment at = null; // 첨부파일 없으면 null로 넘어갈 수 있도록 하자.
				
				if(multiRequest.getOriginalFileName("upfile")!=null) { //넘어온 첨부파일이 있으면!
					
					at = new Attachment();
					at.setOriginName(multiRequest.getOriginalFileName("upfile")); // upfile 이름으로 넘어온 첨부파일 원본명 지정
					at.setChangeName(multiRequest.getFilesystemName("upfile")); // 실제서버에 업로드된 파일명
					at.setFilePath("resources/board_upfiles/");
					
					
				}
				
				// insert처리해주는 서비스 메소드 호출 및 결과 받기
				
				int result = new BoardService().insertBoard(b,at);
				
				if(result>0) { //게시판 삽입 성공한 경우
					
					request.getSession().setAttribute("alertMsg","게시글 등록 성공!");
					response.sendRedirect(request.getContextPath()+"/list.bo");
					
				}else { //게시판 삽입 실패한 경우
					
					request.setAttribute("errorMsg", "게시글 등록 실패!");
					request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
					
				}
				
				
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
