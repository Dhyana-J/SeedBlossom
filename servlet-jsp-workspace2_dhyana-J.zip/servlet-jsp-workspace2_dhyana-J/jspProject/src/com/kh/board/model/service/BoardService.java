package com.kh.board.model.service;
import static com.kh.common.JDBCTemplate.*;
import static com.kh.common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.board.model.dao.BoardDao;
import com.kh.board.model.vo.Attachment;
import com.kh.board.model.vo.Board;
import com.kh.board.model.vo.PageInfo;


public class BoardService {

	public int selectListCount() {
		Connection conn = getConnection();
		int listCount = new BoardDao().selectListCount(conn);
		close(conn);
		return listCount;
	}
	
	public ArrayList<Board> selectList(PageInfo pi){
		Connection conn = getConnection();
		
		ArrayList<Board> list = new BoardDao().selectList(conn,pi);
		
		close(conn);
		
		return list;
	}
	
	public int insertBoard(Board b, Attachment at) {
		
		Connection conn = getConnection();
		
		int result = 0; //최종결과
		
		int result1 = new BoardDao().insertBoard(conn,b);//게시판 삽입 결과
		int result2 = 1; // insertAttach실패하면 0보다 작은값으로 변함. 커밋 안됨.
		
		
		if(at!=null) { //첨부파일 있을 경우
			result2 = new BoardDao().insertAttachment(conn, at);
		}
		
		
		if(result1>0 && result2>0) { // 둘 다 0보다 큰값 반환되어야 커밋됨
			commit(conn);
			result = 1; //수행 잘 되면 최종결과 1로 바꿔준다.
		}else {
			rollback(conn);
		}
		
		
		close(conn);
		
		return result; // 혹은 return result1*result2
	}
	
}
