package com.kh.board.model.dao;

import static com.kh.common.JDBCTemplate.close;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

import com.kh.board.model.vo.Attachment;
import com.kh.board.model.vo.Board;
import com.kh.board.model.vo.PageInfo;

public class BoardDao {

		private Properties prop = new Properties();
		
		public BoardDao() {
			//getResource하면 아래와같은 절대경로를 가져온다.
			//C:\Users\Dhyana-J\Desktop\KH\5_Server\servlet-jsp-workspace2\jspProject\WebContent\WEB-INF\classes\sql\board\board-mapper.xml
			try {
				prop.loadFromXML(new FileInputStream(BoardDao.class.getResource("/sql/board/board-mapper.xml").getPath()));
			} catch (InvalidPropertiesFormatException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		public int selectListCount(Connection conn) {
			
			int listCount = 0;
			Statement stmt = null;
			ResultSet rset = null;
			
			String sql = prop.getProperty("listCount");
			
			try {
				stmt = conn.createStatement();
				rset = stmt.executeQuery(sql);
				
				if(rset.next()) { //한 행만 조회하므로 if를 쓴다.
					listCount = rset.getInt("LISTCOUNT");
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close(rset);
				close(stmt);
			}
			return listCount;
			
		}
		
		public ArrayList<Board> selectList(Connection conn, PageInfo pi){
			
			ArrayList<Board> list = new ArrayList<>();
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			String sql = prop.getProperty("selectList");
			
			try {
				pstmt = conn.prepareStatement(sql);
				
				/*
				 * boardLimit : 10라는 가정하에
				 * currentPage = 1 => startRow : 1 endRow : 10
				 * ''		   = 2 => startRow : 11 endRow : 20
				 * ''		   = 3 => startRow : 21 endRow : 30
				 * 
				 * startRow = (currentPage -1) * boardLimit + 1
				 * endRow = startRow boardLimit - 1
				 */
				int startRow = (pi.getCurrentPage() - 1)*pi.getBoardLimit()+1;
				int endRow = startRow + pi.getBoardLimit() - 1;
				
				pstmt.setInt(1,startRow);
				pstmt.setInt(2,endRow);
				rset = pstmt.executeQuery();
				
				while(rset.next()) {
					list.add(new Board(rset.getInt("BOARD_NO"),
									   rset.getString("CATEGORY_NO"),
									   rset.getString("BOARD_TITLE"),
									   rset.getString("BOARD_WRITER"),
									   rset.getInt("COUNT"),
									   rset.getDate("CREATE_DATE")));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close(rset);
				close(pstmt);
			}
			
			
			
			return list;
		}
		
		//게시글에 첨부파일 있는 경우 첨부파일삽입
		public int insertAttachment(Connection conn, Attachment at) {
			
			int result = 0;
			PreparedStatement pstmt = null;
			String sql = prop.getProperty("insertAttachment"); //게시글 삽입 sql
			
			try {
				pstmt = conn.prepareStatement(sql);
				
				
				pstmt.setString(1, at.getOriginName());
				pstmt.setString(2, at.getChangeName());
				pstmt.setString(3, at.getFilePath());
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close(pstmt);
			}
			
			return result;
		}
		
		//게시글 삽입
		public int insertBoard(Connection conn, Board b) {
			
			int result = 0;
			PreparedStatement pstmt = null;
			String sql = prop.getProperty("insertBoard"); //파일 삽입 sql
			
			try {
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(b.getCategoryNo()));
				pstmt.setString(2, b.getBoardTitle());
				pstmt.setString(3, b.getBoardContent());
				pstmt.setInt(4, Integer.parseInt(b.getBoardWriter()));
				
				result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				close(pstmt);
			}
			
			
			return result;
		}
		
}
