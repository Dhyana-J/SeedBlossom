package com.kh.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCTemplate {

	// 모든 메소드들 static

	//1. Connection 객체 생성(DB접속) 후 생성된 Connection 반환해주는 getConnection 메소드
	public static Connection getConnection() {

		Connection conn = null;

		Properties prop = new Properties(); // Map계열 컬렉션(key-value 세트)

		try {
			//읽어들이고자 하는 driver.properties파일의 물리적인 경로
			String fileName = JDBCTemplate.class.getResource("/sql/driver/driver.properties").getPath();
			//파일 읽어올 때는 항상 WEB-INF에 동기화되어있는 경로를 제시해주어야한다! src폴더 말고!
			prop.load(new FileInputStream(fileName)); 
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		try {
			// 1) Oracle Driver class 등록
			//			Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName(prop.getProperty("driver"));

			//2 ) Connection 객체 생성(DB와 접속)
			//			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SERVER", "SERVER");
			conn = DriverManager.getConnection(prop.getProperty("url"),
					prop.getProperty("username"),
					prop.getProperty("password"));
			
			

		} catch (ClassNotFoundException | SQLException e) { //ojdbc6.jar 추가 안되어있거나, 오타있으면 오류뜬다. WEB-INF/lib에 추가하면됨
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}


	//2. Connection 객체 전달 받아 commit 해주는 commit 메소드
	public static void commit(Connection conn) {


		try {
			if(conn!=null&& !conn.isClosed()) {
				conn.commit();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//3. Connection 객체 전달 받아 rollback해주는  rollback 메소드
	public static void rollback(Connection conn) {
		try {
			if(conn!=null&&!conn.isClosed()) {
				conn.rollback();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//4. Connection객체 전달받아 close해주는 close메소드
	public static void close(Connection conn) {
		try {
			if(conn!=null&&conn.isClosed()) {
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//5. Statement관련객체 전달받아 close해주는 close메소드
	//overloading
	public static void close(Statement stmt) {
		try {
			if(stmt!=null && stmt.isClosed()) {
				stmt.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//6. ResultSet객체 전달받아 close시켜주는 close메소드
	public static void close(ResultSet rset) {
		try {
			if(rset!=null&&rset.isClosed()) {
				rset.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
