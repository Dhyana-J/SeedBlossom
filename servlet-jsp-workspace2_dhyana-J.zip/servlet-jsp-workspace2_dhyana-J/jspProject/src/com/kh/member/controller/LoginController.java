package com.kh.member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/login.me")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		// 요청시 전달값 == request의 parameter영역
		
		// 1. 전달값에 한글이 있을 경우 인코딩 처리해야된다. (post방식만. get은 안깨진다.)
		request.setCharacterEncoding("utf-8");
		
		// 2. 요청시 전달값 꺼내서 변수 또는 객체에 기록해야된다.
		String userId = request.getParameter("userId");
		String userPwd = request.getParameter("userPwd");
				
		// 3. 해당 요청을 처리하는 서비스 클래스
		Member loginUser = new MemberService().loginMember(userId,userPwd);
		
		// 4. 반환받은 결과를 가지고 사용자가 보게 될 응답 뷰 (화면) 지정
		if(loginUser == null) { // 로그인 실패 => 에러페이지
//			System.out.println("로그인실패!");
			
			//응답할 뷰에 필요한 데이터 request의 attribute에 담기 (setAttribute("키",밸류))
			request.setAttribute("errorMsg", "로그인에 실패했습니다.");
			
			// 응답페이지를 JSP에게 위임(제어권 넘김)할 때 필요한 객체(클래스) : RequestDispatcher
			RequestDispatcher view = request.getRequestDispatcher("views/common/errorPage.jsp");
			view.forward(request, response);
			
			//forwarding방식 : 해당 선택된 뷰가 보여질 뿐 url에는 여전히 현재 이 서블릿의 매핑값이 남아있음.
			
			
		}else { //로그인 성공 => index 페이지
//			System.out.println("로그인 성공");
			
			/*
			 * 데이터를 담을 수 있는 영역(JSP내장 객체 4종류)
			 * 
			 * 1) application : application에 담은 데이터는 해당 web application 전역에서 꺼내쓸 수 있다.
			 * 					공유범위가 제일 큼
			 * 2) session	  : session에 담은 데이터는 모든 jsp와 모든 servlet상에서 꺼내쓸 수 있음
			 * 					공유범위가 jsp/servlet
			 * 3) request	  : request에 담은 데이터는 해당 request객체가 전달된 응답 jsp에서만 꺼내쓸 수 있음
			 * 					공유범위 제한적
			 * 4) page		  : page에 담은 데이터는 해당 jsp페이지에서만 꺼내쓸 수 있음
			 * 					공유범위 가장 좁다.
			 * 
			 * 로그인한 회원정보(loginUser)를 session에 한 번만 담아두면,
			 * 어느 페이지던간에 sesison에 담겨있는 회원객체에 대한 정보를 뽑아서 꺼내쓸 수 있음
			 * 
			 * 위의 4개의 객체에
			 * 데이터를 담고자 할 때 .setAttribute("키",밸류)를 이용
			 * 		  뽑고자 할 때 .getAttribute("키")를 이용
			 * 		  지우고자 할 때 .removeAttribute("키")를 이용.
			 * */
			
//			Servlet클래스에서 JSP내장객체인 session에 접근하고자 한다면 우선 세션 객체를 얻어와야한다.
			HttpSession session = request.getSession();
			session.setAttribute("loginUser",loginUser);
//			session.setAttribute(); //session이 선언되어있지 않으므로 바로 못쓴다.
			
			
			
			/* index페이지 잘 보여지지만, url에 여전히 login.me가 남아있음
			RequestDispatcher view = request.getRequestDispatcher("index.jsp");
			view.forward(request, response);
			*/
			
			//2. redirect방식 (url을 재요청하는 방식)
			response.sendRedirect(request.getContextPath()); //request객체 전달 안함. 
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
